# PR #102 frozen 2.19 update independent review — 2026-10-08

Reviewed the five-file dirty update on HEAD 884ae1bee1d20101877b39213491b0ce795017de, inheriting the 2.17 review. Source remains uncommitted; this reviewer did not edit repository source, spawn agents, commit, push or publish.

## Result

No newly confirmed production defect in the dependency/static configuration diff. **Follow-up closure: the isolated trust regression now passes after the test fixture was made actually untrusted; full four-path validation remains pending.** Do not mark the update complete or promote the candidate from the isolated result alone.

Root's local IntelliJ IDEA EAP 2.19 JUnit outputs were independently read and copied: 40 tests, 39 passed, 1 failed, 0 errors/skips. Filetype/editor/settings/gutter/process failures from 2.17 are absent from this run. The one failure is NagiRunLineMarkerTest.testUntrustedProjectCannotInvokeCompiler: “untrusted project input should remain unsaved,” test line124. This is a local IC result only, not four-path CI/Verifier success.

## Trust failure: confirmed observation, unresolved attribution

Production NagiCompilerAction.execute lines46–50 checks TrustedProjects.isProjectTrusted and returns on denial before saveInputs at52, settings lookup, command construction and task startup. Its Java source was unchanged by this update. The test first marks the document unsaved at118, invokes the action at120, then calls PlatformTestUtil.waitForAllBackgroundActivityToCalmDown at121. The compiler recorder absence assertion at123 passed; the later unsaved assertion at124 failed.

These facts do not identify who saved the document or establish the trust value at invocation. A bundling/fixture background-save effect is plausible; production action regression is not proven. Preserve the assertions. Narrow follow-up: capture trust immediately before execute; observe denial dialog; assert unsaved immediately after execute; use a FileDocumentManagerListener to record any beforeDocumentSaving/saveAll caller stack while retaining the delayed no-compiler check. This separates the action boundary from IDE-host background activity without suppressing either signal. SDK helper/save attribution was not investigated further at the parent's request.

Original current JUnit XML is copied under independent-local-ic-eap-junit/, and the exact readback is independent-trust-read.json. Do not replace this RED evidence with a later GREEN run.

## Official source and static review

Fresh official GitHub reads at tag2.19.0 exactly matched every provided primary-source/changelog string (primary-comparison.json).

- [TestIdeTask](https://github.com/JetBrains/intellij-platform-gradle-plugin/blob/2.19.0/src/main/kotlin/org/jetbrains/intellij/platform/gradle/tasks/TestIdeTask.kt), blob c6577cf19379340ecb006b1e7b6ba8507b73e4dd: obtains the selected platform path, reads productInfo().bundledPlugins, resolves plugin IDs/module aliases through IdeLayoutIndexService, adds resolved and distinct SDK classpath entries, and retains IdeaHomePathArgumentProvider. Classpath inclusion has an enable/exclude provider; official changelog says enabled by default.
- [Changelog](https://github.com/JetBrains/intellij-platform-gradle-plugin/blob/2.19.0/CHANGELOG.md), blob8e88d38f804233e6b723daa78670df85c6fa4044: 2.18.0 introduced bundled-plugin classpath handling; 2.18.1 excluded translation and Vue plugins. The 2.19 tag's newest section is labeled [next], so no dated 2.19 heading is invented.
- [VerifyPluginTask](https://github.com/JetBrains/intellij-platform-gradle-plugin/blob/2.19.0/src/main/kotlin/org/jetbrains/intellij/platform/gradle/tasks/VerifyPluginTask.kt), blob123c8201ec513b810f408c31503fab7fa7804c69: archiveFile/freeArgs override remain available. New useBundledRuntime defaults to true: it omits forced -runtime-dir and resolves against each verified IDE's bundled JBR, exposing the configured runtime through JAVA_HOME as fallback when a target lacks JBR. This runtime resolution differs from the Gradle JVM/javac toolchain; it does not raise plugin bytecode/API level. Report-based failure detection and missing-verdict fail-closed behavior strengthen validation.
- [Constants](https://github.com/JetBrains/intellij-platform-gradle-plugin/blob/2.19.0/src/main/kotlin/org/jetbrains/intellij/platform/gradle/Constants.kt), blob5829c9bb03bbfe8c515ed1fff255b0db2039cb01: minimum Gradle9.0.0; wrapper9.4.0 remains compatible.

The diff changes only dependency version, CI expected version and five-file documentation. Plugin ID/version0.1.1, minimum251.25410.109/2025.1.1 IC/PC targets, direct public trust call, explicit release/source/target21 and EAP javac25 are preserved. New upstream removal of implicit release convention is harmless here because options.release is explicitly set/guarded. No setupDependencies reference, disabling bundled plugin classpath, failure suppression, or new compatibility-warning mute was found. TemplateWordInPluginName remains the sole mute. Workflow and Java source are unchanged: the once-built common candidate archive and four test/Verifier paths still gate promotion.

Historical documentation accurately keeps the 2.17 EAP failures separate from the home-path failure. Provided prior CI snapshot reports both stable jobs successful, both EAP tests failed, both EAP verifiers successful, and package skipped. The supplied JUnit set independently totals40/18failed/0skipped. Both-product exact counts rely on the parent’s raw readbacks; this reviewer did not independently redownload every prior CI artifact.

## Executed checks and remaining limits

Independent Python CI suite: 62 passed in7.852seconds, exit0. git diff --check passed. Full source hashes, frozen diff, official source blob IDs and executed command ledger are preserved here.

No independent Gradle execution was launched. Root's actual local IC EAP JUnit was inspected, not counted as an independently executed test. Current PC EAP/stable targets and exact candidate ZIP Verifier after2.19 remain unconfirmed. No Marketplace/UI installation, merge, version/tag/release/upload approval or success claim is implied.



## Final narrow trust-fixture follow-up

The production source and workflow are unchanged. Test JVM only now sets idea.trust.headless.disabled=false inside tasks.test. The Java test asserts actual isProjectTrusted=false immediately before execution and unsaved immediately after execution, preserving the original post-background unsaved and no-compiler assertions. This strengthens the tested precondition and action boundary without relaxing the original signals or adding an internal API reference to shipped code.

The preserved isolated RED XML reports1 test/1 failure/0 skips at the newly observed pre-execute actual-trust assertion: setProjectTrusted(false) had not made the effective project untrusted in this headless/unit test host. The exact SDK javap shows getProjectTrustedState selecting YES when isTrustedCheckDisabledForProduct is true, before honoring the explicit saved state. isTrustedCheckDisabled defaults idea.trust.headless.disabled to true in unit-test/headless mode. The related primary Kotlin source agrees on that shortcut. The preserved isolated GREEN XML reports1 test/0 failures/errors/skips; its log ends BUILD SUCCESSFUL. This resolves the tested fixture cause; the previous background-autosave hypothesis was not established and is not the conclusion.

No new production defect or blocking issue in this narrow fix was found. One nonblocking documentation precision issue remains: primary.kt calls getStateProvider in getProjectTrustedState, whereas the inspected SDK javap directly calls TrustedPaths.getInstance. Thus the saved primary is related source agreeing on the shortcut, not established as the exact source revision of the SDK artifact. Replace 'exact SDK source snapshot' with 'related primary source and actual SDK javap' unless the matching revision is independently established. The bytecode is sufficient evidence for the relevant shortcut and the isolated GREEN verifies this correction in the host.

Follow-up reviewer checks were read-only source/diff inspection, isolated RED/GREEN XML/log readback, production/workflow unchanged comparison, and git diff --check (exit0). No new tests were executed by this reviewer, as requested. Worker reports static guards63 passed; that count was not independently rerun here. Full40 IC EAP rerun and remaining three SDK paths plus exact ZIP Verifier are not claimed successful. New source/evidence hashes are in independent-trust-followup-source-manifest.json. The earlier RED40-test outputs remain separately preserved.
